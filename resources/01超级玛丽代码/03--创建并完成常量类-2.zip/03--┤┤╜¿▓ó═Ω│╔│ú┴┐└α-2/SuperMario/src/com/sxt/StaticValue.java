package com.sxt;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class StaticValue {
    //背景
    public static BufferedImage bg = null;
    public static BufferedImage bg2 = null;
    //马里奥向左跳跃
    public static BufferedImage jump_L = null;
    //马里奥向右跳跃
    public static BufferedImage jump_R = null;
    //马里奥向左站立
    public static BufferedImage stand_L = null;
    //马里奥向右站立
    public static BufferedImage stand_R = null;
    //城堡
    public static BufferedImage tower = null;
    //旗杆
    public static BufferedImage gan = null;
    //障碍物
    public static List<BufferedImage> obstacle = new ArrayList<>();
    //马里奥向左跑
    public static List<BufferedImage> run_L = new ArrayList<>();
    //马里奥向右跑
    public static List<BufferedImage> run_R = new ArrayList<>();
    //蘑菇敌人
    public static List<BufferedImage> mogu = new ArrayList<>();
    //食人花敌人
    public static List<BufferedImage> flower = new ArrayList<>();
    //路径的前缀,方便后续调用
    public static String path = System.getProperty("user.dir") + "/src/images/";

    //初始化方法
    public static void init() {

    }
}
