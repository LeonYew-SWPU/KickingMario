package com.sxt;

import java.awt.image.BufferedImage;

public class StaticValue {
    //背景
    public static BufferedImage bg = null;
    public static BufferedImage bg2 = null;
    //马里奥向左跳跃
    public static BufferedImage jump_L = null;
    //马里奥向右跳跃
    public static BufferedImage jump_R = null;
    //马里奥向左站立
    public static BufferedImage stand_L = null;
    //马里奥向右站立
    public static BufferedImage stand_R = null;
    //城堡
    public static BufferedImage tower = null;
    //旗杆
    public static BufferedImage gan = null;
}
